package com.virtusa.vrps.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.vrps.models.RatingAndComments;
import com.virtusa.vrps.repositories.RatingAndCommentsRepo;

@Service
public class RatingAndCommentsService {

	@Autowired
	private RatingAndCommentsRepo ratingAndCommentsRepo;
	
	public RatingAndComments saveRatingAndComment(RatingAndComments ratingAndComment)
	{
		return ratingAndCommentsRepo.save(ratingAndComment);
	}
	
	public List<RatingAndComments> getRatingsAndComments(int employeeId) {
		return ratingAndCommentsRepo.getAllRatingsAndComments(employeeId);
		
	}
	
	
}
