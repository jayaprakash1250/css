package com.virtusa.vrps.controllers;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.models.Company;
import com.virtusa.vrps.models.Education;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Personal;
import com.virtusa.vrps.models.Work;
import com.virtusa.vrps.services.ApplicationService;
import com.virtusa.vrps.services.CompanyService;
import com.virtusa.vrps.services.EducationService;
import com.virtusa.vrps.services.EmployeeService;
import com.virtusa.vrps.services.PersonalService;
import com.virtusa.vrps.services.WorkService;

@Controller
public class CreateProfileController {

	@Autowired
	private PersonalService personalService;

	@Autowired
	private WorkService workService;

	@Autowired
	EmployeeService employeeService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private EducationService educationService;
	@Autowired
	private ApplicationService applicationService;

	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    @Autowired
	HttpSession httpSession;

	@RequestMapping(value = "/savePersonal", method = RequestMethod.POST)
	public @ResponseBody String savePersonal(@RequestBody Personal personal, Employee employee, Model model) {
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());

		employee = employeeService.getEmployee(employeeId);
		personal.setEmployee(employee);
		model.addAttribute("personal", personalService.savePersonal(personal));

		String userId = authentication.getName();
		String role = authentication.getAuthorities().toString();

		System.out.println("this is from " + userId + "  " + role);

		return "";

	}

	@RequestMapping(value = "/saveWork", method = RequestMethod.POST)
	public @ResponseBody void saveWork(@RequestBody Work work, Employee employee, Model model) { //
		/*
		 * //model.addAttribute("work", workService.saveWork(work)); employee = //
		 * employeeService.getEmployee(1234); work.setEmployee(employee);
		 * workService.saveWork(work);
		 */
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		employee = employeeService.getEmployee(employeeId);
		work.setEmployee(employee);
		model.addAttribute("personal", workService.saveWork(work));

	}

	@RequestMapping(value = "/saveCompany", method = RequestMethod.POST)

	public @ResponseBody void saveCompany(@RequestBody Company[] groupcompany, Employee employee, Model model) {
       
		// model.addAttribute("company", companyService.saveCompany(company));
	
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		Work work = workService.getWorkById(employeeId);
		for (int i = 0; i < groupcompany.length; i++) {
			groupcompany[i].setWork(work);
			companyService.saveCompany(groupcompany[i]);
		}
	}

	@RequestMapping(value = "/saveEducation", method = RequestMethod.POST)

	public @ResponseBody void saveEducation(@RequestBody Education[] groupeducation, Employee employee, Model model) {
		int employeeId = Integer.parseInt(httpSession.getAttribute("userId").toString());
		employee = employeeService.getEmployee(employeeId);
		for (int i = 0; i < groupeducation.length; i++) {
			groupeducation[i].setEmployee(employee);
			educationService.saveEducation(groupeducation[i]);
		}

	}

	
	
	  @RequestMapping(value = "/saveApplication", method = RequestMethod.POST)
	  public @ResponseBody void saveApplication(@RequestBody Application
	  application, Employee employee, Model model) { //
	  
	  //model.addAttribute("work", workService.saveWork(work)); employee = // //
	  employeeService.getEmployee(1234);
	  
	  
	  int
	  employeeId=Integer.parseInt(httpSession.getAttribute("userId").toString());
	  employee = employeeService.getEmployee(employeeId);
	  application.setEmployee(employee);
	  model.addAttribute("application",applicationService.saveApplication(
	  application));
	  
	  
	  
	  
	  }
	 
	 
	 

}
