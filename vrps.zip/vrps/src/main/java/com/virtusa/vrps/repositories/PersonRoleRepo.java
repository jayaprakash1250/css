package com.virtusa.vrps.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.virtusa.vrps.models.PersonRole;

public interface PersonRoleRepo extends JpaRepository<PersonRole, Integer> {
	@Query("SELECT pr FROM PersonRole pr WHERE pr.person.employeeId = :employeeid")
	List<PersonRole> getUserRolesByID(@Param("employeeid") int employeeid);

}
