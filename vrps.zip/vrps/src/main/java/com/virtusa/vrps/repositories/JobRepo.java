package com.virtusa.vrps.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.vrps.models.Job;

public interface JobRepo extends JpaRepository<Job, Integer>{

}
